var Mos = "#222"; // Màu tuỳ chọn. Mặc định "#36a6ed" .
var Color = "#36a6ed"; // Màu tuỳ chọn. Mặc định "#36a6ed" .
var scle = 0.95; // Tuỳ chỉnh kích cỡ
