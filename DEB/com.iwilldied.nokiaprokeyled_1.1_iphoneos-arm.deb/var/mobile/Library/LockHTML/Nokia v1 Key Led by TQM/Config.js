var QuangMinh = "😉•0868.388.373•❤️"; // Tuỳ chọn ký tự.
var QuangMinh1 = "Menu"; // Tuỳ chọn ký tự.
var QuangMinh2 = "Chọn"; // Tuỳ chọn ký tự.
var twentyfourhour = true; // Bặt hoặc tắt. Định dạng 24h
var pad = true; // Bặt hoặc tắt. Định dạng giờ vd.( 00 ) hoặc ( 0 )
