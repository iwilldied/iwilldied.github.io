var current = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'en',
    $$ = function (el) {
        return document.getElementById(el);
    },
    translate = {
        vi: {
            weekday: ["Chủ nhật","Thứ hai","Thứ ba","Thứ tư","Thứ năm","Thứ sáu","Thứ bảy"],
            month: ["Tháng 1","Tháng 2","Tháng 3","Tháng 4","Tháng 5","Tháng 6","Tháng 7","Tháng 8","Tháng 9","Tháng 10","Tháng 11","Tháng 12"]
        },
        en: {
            weekday: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
            month: ["January","February","March","April","May","June","July","August","September","October","November","December"]
        }
    };
if (!translate[current]) {
    current = 'en';
}
